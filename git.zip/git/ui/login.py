# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'login.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_LoginWin(object):
    def setupUi(self, LoginWin):
        LoginWin.setObjectName("LoginWin")
        LoginWin.resize(400, 300)
        LoginWin.setMinimumSize(QtCore.QSize(400, 300))
        LoginWin.setMaximumSize(QtCore.QSize(400, 300))
        LoginWin.setSizeIncrement(QtCore.QSize(400, 300))
        LoginWin.setStyleSheet("#LoginWin { \n"
" border-image: url(./back_image/login.png); \n"
" } ")
        self.loginButton = QtWidgets.QPushButton(LoginWin)
        self.loginButton.setGeometry(QtCore.QRect(160, 200, 80, 30))
        self.loginButton.setStyleSheet("background-color: rgb(170, 170, 255);")
        self.loginButton.setObjectName("loginButton")
        self.numEdit = QtWidgets.QLineEdit(LoginWin)
        self.numEdit.setGeometry(QtCore.QRect(130, 70, 141, 41))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.numEdit.setFont(font)
        self.numEdit.setStyleSheet("background-color: rgb(0, 255, 255);")
        self.numEdit.setText("")
        self.numEdit.setCursorPosition(0)
        self.numEdit.setAlignment(QtCore.Qt.AlignLeading|QtCore.Qt.AlignLeft|QtCore.Qt.AlignVCenter)
        self.numEdit.setReadOnly(False)
        self.numEdit.setObjectName("numEdit")
        self.passwdEdit = QtWidgets.QLineEdit(LoginWin)
        self.passwdEdit.setGeometry(QtCore.QRect(130, 130, 141, 41))
        font = QtGui.QFont()
        font.setPointSize(10)
        self.passwdEdit.setFont(font)
        self.passwdEdit.setAutoFillBackground(False)
        self.passwdEdit.setStyleSheet("background-color: rgb(0, 255, 255);")
        self.passwdEdit.setText("")
        self.passwdEdit.setEchoMode(QtWidgets.QLineEdit.Password)
        self.passwdEdit.setCursorPosition(0)
        self.passwdEdit.setAlignment(QtCore.Qt.AlignLeading|QtCore.Qt.AlignLeft|QtCore.Qt.AlignVCenter)
        self.passwdEdit.setDragEnabled(False)
        self.passwdEdit.setReadOnly(False)
        self.passwdEdit.setCursorMoveStyle(QtCore.Qt.LogicalMoveStyle)
        self.passwdEdit.setClearButtonEnabled(False)
        self.passwdEdit.setObjectName("passwdEdit")

        self.retranslateUi(LoginWin)
        self.loginButton.clicked.connect(LoginWin.showAdmin)
        QtCore.QMetaObject.connectSlotsByName(LoginWin)

    def retranslateUi(self, LoginWin):
        _translate = QtCore.QCoreApplication.translate
        LoginWin.setWindowTitle(_translate("LoginWin", "管理员登录"))
        self.loginButton.setText(_translate("LoginWin", "登录"))
        self.numEdit.setPlaceholderText(_translate("LoginWin", "账号"))
        self.passwdEdit.setPlaceholderText(_translate("LoginWin", "密码"))

