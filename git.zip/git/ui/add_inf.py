# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'add_inf.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_AddWin(object):
    def setupUi(self, AddWin):
        AddWin.setObjectName("AddWin")
        AddWin.resize(490, 360)
        AddWin.setMinimumSize(QtCore.QSize(490, 360))
        AddWin.setMaximumSize(QtCore.QSize(490, 360))
        AddWin.setSizeIncrement(QtCore.QSize(490, 360))
        AddWin.setStyleSheet("#AddWin { \n"
" border-image: url(./back_image/add.png); \n"
" } ")
        self.captureButton = QtWidgets.QPushButton(AddWin)
        self.captureButton.setGeometry(QtCore.QRect(80, 250, 80, 31))
        font = QtGui.QFont()
        font.setFamily("Agency FB")
        font.setPointSize(14)
        self.captureButton.setFont(font)
        self.captureButton.setStyleSheet("background-color: rgb(0, 170, 255);")
        self.captureButton.setObjectName("captureButton")
        self.addButton = QtWidgets.QPushButton(AddWin)
        self.addButton.setGeometry(QtCore.QRect(340, 250, 80, 31))
        font = QtGui.QFont()
        font.setFamily("Agency FB")
        font.setPointSize(14)
        self.addButton.setFont(font)
        self.addButton.setStyleSheet("background-color: rgb(85, 170, 255);")
        self.addButton.setObjectName("addButton")
        self.nameEdit = QtWidgets.QTextEdit(AddWin)
        self.nameEdit.setGeometry(QtCore.QRect(160, 90, 181, 41))
        font = QtGui.QFont()
        font.setFamily("宋体")
        font.setPointSize(14)
        self.nameEdit.setFont(font)
        self.nameEdit.setStyleSheet("background-color: rgb(0, 255, 255);")
        self.nameEdit.setObjectName("nameEdit")
        self.numEdit = QtWidgets.QTextEdit(AddWin)
        self.numEdit.setGeometry(QtCore.QRect(160, 160, 181, 41))
        font = QtGui.QFont()
        font.setFamily("宋体")
        font.setPointSize(14)
        self.numEdit.setFont(font)
        self.numEdit.setStyleSheet("background-color: rgb(0, 255, 255);")
        self.numEdit.setObjectName("numEdit")
        self.name_label = QtWidgets.QLabel(AddWin)
        self.name_label.setGeometry(QtCore.QRect(110, 90, 54, 31))
        font = QtGui.QFont()
        font.setFamily("Agency FB")
        font.setPointSize(14)
        self.name_label.setFont(font)
        self.name_label.setObjectName("name_label")
        self.num_label = QtWidgets.QLabel(AddWin)
        self.num_label.setGeometry(QtCore.QRect(110, 160, 54, 31))
        font = QtGui.QFont()
        font.setFamily("Agency FB")
        font.setPointSize(14)
        self.num_label.setFont(font)
        self.num_label.setObjectName("num_label")
        self.addPhotoButton = QtWidgets.QPushButton(AddWin)
        self.addPhotoButton.setGeometry(QtCore.QRect(190, 250, 120, 31))
        font = QtGui.QFont()
        font.setPointSize(14)
        self.addPhotoButton.setFont(font)
        self.addPhotoButton.setStyleSheet("background-color: rgb(85, 170, 255);")
        self.addPhotoButton.setObjectName("addPhotoButton")

        self.retranslateUi(AddWin)
        self.captureButton.clicked.connect(AddWin.capFace)
        self.addButton.clicked.connect(AddWin.addStaff)
        self.addPhotoButton.clicked.connect(AddWin.addPhoto)
        QtCore.QMetaObject.connectSlotsByName(AddWin)

    def retranslateUi(self, AddWin):
        _translate = QtCore.QCoreApplication.translate
        AddWin.setWindowTitle(_translate("AddWin", "信息录入"))
        self.captureButton.setText(_translate("AddWin", "拍照"))
        self.addButton.setText(_translate("AddWin", "确定"))
        self.nameEdit.setHtml(_translate("AddWin", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'宋体\'; font-size:14pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p></body></html>"))
        self.numEdit.setHtml(_translate("AddWin", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'宋体\'; font-size:14pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p></body></html>"))
        self.name_label.setText(_translate("AddWin", "姓名"))
        self.num_label.setText(_translate("AddWin", "编号"))
        self.addPhotoButton.setText(_translate("AddWin", "本地添加照片"))

