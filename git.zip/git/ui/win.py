# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'win.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.setEnabled(True)
        MainWindow.resize(700, 400)
        MainWindow.setMinimumSize(QtCore.QSize(700, 400))
        MainWindow.setMaximumSize(QtCore.QSize(700, 400))
        MainWindow.setSizeIncrement(QtCore.QSize(700, 400))
        MainWindow.setStyleSheet("background-color: rgb(135, 206, 235);\n"
"\n"
"")
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(30, 70, 471, 300))
        self.label.setStyleSheet("\n"
"background-color: rgb(0, 0, 0);\n"
"")
        self.label.setText("")
        self.label.setObjectName("label")
        self.verticalLayoutWidget = QtWidgets.QWidget(self.centralwidget)
        self.verticalLayoutWidget.setGeometry(QtCore.QRect(520, 70, 141, 261))
        self.verticalLayoutWidget.setObjectName("verticalLayoutWidget")
        self.verticalLayout = QtWidgets.QVBoxLayout(self.verticalLayoutWidget)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setObjectName("verticalLayout")
        self.adminButton = QtWidgets.QPushButton(self.verticalLayoutWidget)
        self.adminButton.setMinimumSize(QtCore.QSize(0, 50))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.adminButton.setFont(font)
        self.adminButton.setStyleSheet("background-color: rgb(0, 201, 87);")
        self.adminButton.setObjectName("adminButton")
        self.verticalLayout.addWidget(self.adminButton)
        self.punchButton = QtWidgets.QPushButton(self.verticalLayoutWidget)
        self.punchButton.setMinimumSize(QtCore.QSize(0, 50))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.punchButton.setFont(font)
        self.punchButton.setStyleSheet("background-color: rgb(0, 201, 87);")
        self.punchButton.setObjectName("punchButton")
        self.verticalLayout.addWidget(self.punchButton)
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(200, 0, 131, 21))
        font = QtGui.QFont()
        font.setFamily("微软雅黑")
        font.setPointSize(14)
        font.setBold(False)
        font.setWeight(50)
        self.label_2.setFont(font)
        self.label_2.setObjectName("label_2")
        self.showResult = QtWidgets.QLabel(self.centralwidget)
        self.showResult.setGeometry(QtCore.QRect(140, 40, 231, 21))
        font = QtGui.QFont()
        font.setPointSize(16)
        self.showResult.setFont(font)
        self.showResult.setText("")
        self.showResult.setAlignment(QtCore.Qt.AlignCenter)
        self.showResult.setObjectName("showResult")
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 700, 23))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        self.punchButton.clicked.connect(MainWindow.showCamera)
        self.adminButton.clicked.connect(MainWindow.showLogin)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "人脸识别系统"))
        self.adminButton.setText(_translate("MainWindow", "系统管理"))
        self.punchButton.setText(_translate("MainWindow", "识别"))
        self.label_2.setText(_translate("MainWindow", "请正脸识别"))

