import tensorflow as tf
import numpy as np
import cv2, os
from face_recog import facenet
from face_detect.face_detector import FaceDetector
os.environ['CUDA_VISIBLE_DEVICES'] = '0,1'

dir_model = './model'
dir_image_train = './image_train'

MODEL_PATH = dir_model + '/faceboxes_model/model.pb'
face_detector = FaceDetector(MODEL_PATH, gpu_memory_fraction=0.25, visible_device_list='0')

model_dir = dir_model + '/facenet_model/facenet_model.pb'

# 建立facenet embedding模型
tf.Graph().as_default()
sess = tf.Session()
facenet.load_model(model_dir)
images_placeholder = tf.get_default_graph().get_tensor_by_name("input:0")
embeddings = tf.get_default_graph().get_tensor_by_name("embeddings:0")
phase_train_placeholder = tf.get_default_graph().get_tensor_by_name("phase_train:0")
embedding_size = embeddings.get_shape()[1]


def recg(frame, emb_array_train):
    image_size = 200
    scaled_reshape = []
    target_name = np.load(dir_image_train + '/target_name.npy')
    emb_array_detect = np.zeros((1, embedding_size))

    boxes, scores = face_detector(frame, score_threshold=0.5)
    staff_num = ''   # 员工编号
    max_dis = []  # 存储最大boxes的对角线距离
    for i in range(boxes.shape[0]):
        bbox = boxes[i, :4]
        if int(bbox[0]) > 0 and int(bbox[1]) > 0 and int(bbox[2]) > 0 and int(bbox[3]) > 0:
            x = np.array([int(bbox[1]), int(bbox[0])])   # 左上角坐标
            y = np.array([int(bbox[3] - bbox[1]), int(bbox[2] - bbox[0])])   # 右下角坐标
            dis = np.sqrt(np.sum(np.square(x - y)))   # 两点间欧氏距离
            max_dis.append(dis)   # 如果有多个人脸框，获取最大的那个
            cv2.rectangle(frame, (int(bbox[1]), int(bbox[0])), (int(bbox[3]), int(bbox[2])), (0, 255, 0), 4)
    if len(max_dis) > 0:
        index = max_dis.index(max(max_dis))
        bbox = boxes[index, :4]
        image = frame[int(bbox[0]):int(bbox[2]), int(bbox[1]):int(bbox[3])]
        image = cv2.resize(image, (image_size, image_size), interpolation=cv2.INTER_CUBIC)
        image = facenet.prewhiten(image)
        scaled_reshape = image.reshape(-1, image_size, image_size, 3)
        emb_array_detect[0, :] = sess.run(embeddings, feed_dict={images_placeholder: scaled_reshape, phase_train_placeholder: False})[0]
        for j in range(len(emb_array_train)):
            dist = np.sqrt(np.sum(np.square(emb_array_train[j] - emb_array_detect[0])))   # 人脸间特征欧氏距离
            if dist < 0.4:
                cv2.putText(frame, target_name[j], (int(bbox[1]) - 10, int(bbox[0]) - 10), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2, cv2.LINE_AA)
                staff_num = target_name[j]

    return frame, staff_num

