def recg(frame, emb_array_train):
    image_size = 200
    target_name = np.load(dir_image_train + '/target_name.npy')
    emb_array_detect = np.zeros((1, embedding_size))

    boxes, scores = face_detector(frame, score_threshold=0.5)  # 获取人脸框
    max_dis = []  # 存储最大boxes的对角线距离
    
	……
	
    if len(max_dis) > 0:
        index = max_dis.index(max(max_dis))
        bbox = boxes[index, :4]
        image = frame[int(bbox[0]):int(bbox[2]), int(bbox[1]):int(bbox[3])]
        image = cv2.resize(image, (image_size, image_size), interpolation=cv2.INTER_CUBIC) # 人脸预处理
        image = facenet.prewhiten(image)
        scaled_reshape = image.reshape(-1, image_size, image_size, 3)
        emb_array_detect[0, :] = sess.run(embeddings, feed_dict={images_placeholder: scaled_reshape, \
		phase_train_placeholder: False})[0]  # 特征提取
        for j in range(len(emb_array_train)):
            dist = np.sqrt(np.sum(np.square(emb_array_train[j] - emb_array_detect[0])))   # 人脸间特征欧氏距离
            if dist < 0.4: # 人脸比对
               ……
                staff_num = target_name[j]

    return frame, staff_num
