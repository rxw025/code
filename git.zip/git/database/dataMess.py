import pymysql
import re
import mysql.connector


# 判断数据表是否存在
def table_exist(cur, table_name):
    cur.execute("SHOW TABLES")
    tables = [cur.fetchall()]
    table_list = re.findall('(\'.*?\')', str(tables))
    table_list = [re.sub("'", '', each) for each in table_list]
    if table_name in table_list:
        return True
    else:
        return False


class dataBase:
    def __init__(self):
        self.cur = None
        self.mycursor = None
        self.mydb = None
        self.host = '127.0.0.1'
        self.port = 3306
        self.user = 'root'
        self.passwd = 'mysql1212'
        self.db = 'face'
        self.conn = None

    # 连接数据库
    @property
    def connect(self):
        try:
            flag = 1
            self.mydb = mysql.connector.connect(host=self.host, user=self.user, passwd=self.passwd, charset='utf8')
            # print(self.mydb)
            self.mycursor = self.mydb.cursor()
            self.mycursor.execute("SHOW DATABASES")
            for x in self.mycursor:
                # print(x)
                if x[0] == self.db:
                    flag = 0
                    break
            if flag == 1:
                self.mycursor.execute("CREATE DATABASE {0}".format(self.db))

            self.mydb.close()
            self.conn = pymysql.Connect(host=self.host, port=self.port, user=self.user, passwd=self.passwd, db=self.db,
                                        charset='utf8')

        except:
            return False

        self.cur = self.conn.cursor()  # 获取一个游标

        table_name = "employees"
        table_name1 = 'record'
        table_name2 = 'facefeat'
        table_name3 = 'admin'

        if table_exist(self.cur, table_name) is False:
            self.cur.execute("CREATE TABLE employees (name VARCHAR(255), staffNum VARCHAR(255) PRIMARY KEY)")

        if table_exist(self.cur, table_name1) is False:
            self.cur.execute("CREATE TABLE record (\
                             id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,\
                             staffNum VARCHAR(255),\
                             dates VARCHAR (255),\
                             recordTime timestamp NULL DEFAULT CURRENT_TIMESTAMP,\
                             CONSTRAINT recording FOREIGN KEY (staffNum) REFERENCES employees (staffNum) ON DELETE RESTRICT ON UPDATE RESTRICT )")

        if table_exist(self.cur, table_name2) is False:
            self.cur.execute("CREATE TABLE facefeat (id INT NOT NULL AUTO_INCREMENT PRIMARY KEY , feature LONGBLOB , dimension BLOB)")

        if table_exist(self.cur, table_name3) is False:
            self.cur.execute("CREATE TABLE admin (account_num VARCHAR(255), passwd VARCHAR(255))")
            self.cur.execute("INSERT INTO admin (account_num, passwd) VALUES ('root', '')")
        return True

    # 关闭数据库
    def close(self):
        self.cur.close()  # 关闭游标
        self.conn.close()  # 释放数据库资源
        return True

    # 插入数据
    def execute(self, sql, parma=None):
        self.connect
        if self.conn and self.cur:
            self.cur.execute(sql, parma)
            self.conn.commit()
            # print("insert success")
            return True
        else:
            # print('Insert Error!')
            self.conn.rollback()  # 如果发生错误则回滚
            return False

    # 查询数据
    def fetchall(self, sql):
        self.execute(sql)
        return self.cur.fetchall()  # 获取操作返回的所有的行
