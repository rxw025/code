import sys, cv2, os, pickle
import numpy as np
import time
from datetime import datetime
from database.dataMess import *
from ui import win, add_inf, login, admin
from face_detect.cap_detect import capture_face
from face_detect.image_detect import image_face
from PyQt5.QtWidgets import QApplication, QMainWindow, QDialog, QMessageBox, QFileDialog, QTableWidgetItem
from PyQt5.QtCore import QTimer,  QPoint
from PyQt5.QtGui import QImage, QPixmap
from PyQt5 import Qt, QtWidgets, QtGui, QtCore
#from matplotlib import pyplot as plt
from face_recog.recog import recg
from image_train.data_train import train


image_path = "./image/"


class LoginWin(QDialog, login.Ui_LoginWin):
    def __init__(self):
        super(LoginWin, self).__init__()
        self.setupUi(self)

    def showAdmin(self):
        account_num = self.numEdit.text()
        passwd = self.passwdEdit.text()
        dBase = dataBase()
        sql = "select count(*) from admin where account_num='%s' and passwd='%s'"%(account_num, passwd)
        result = dBase.fetchall(sql)[0]
        count = result[0]
        if count == 0:
            QMessageBox.information(self, '提示', '用户名或者密码错误', QMessageBox.Yes)
        else:
            self.close()
            adm = AdminWin()
            adm.show()
            adm.exec_()


class AddWin(QDialog, add_inf.Ui_AddWin):
    def __init__(self):
        super(AddWin, self).__init__()
        self.setupUi(self)

    # 添加员工
    def addStaff(self):
        dBase = dataBase()
        staffName = self.nameEdit.toPlainText()
        staffNum = self.numEdit.toPlainText()
        if staffName == '' or staffNum == '':
            QMessageBox.information(self, "信息录入", "请完善个人信息")
        else:
            flag = True
            sql = 'SELECT * FROM employees'
            result = dBase.fetchall(sql)
            for i in range(len(result)):
                if result[i][1] == staffNum:
                    flag = False
                    QMessageBox.information(self, "信息录入", "编号重复了！")
            if flag:
                if os.path.exists(image_path + staffNum):
                    if os.listdir(image_path + staffNum):
                        try:
                            sql = "insert into employees values('{0}', '{1}')".format(staffName, staffNum)
                            dBase.execute(sql)
                            face_feature, dimension = train()
                            bytes_feature = face_feature.tobytes()
                            matrix_dimension = pickle.dumps(dimension)
                            sql = "insert into facefeat (feature) values(%s)"
                            dBase.execute(sql, bytes_feature)
                            sql = "update facefeat set dimension=%s where id in (select a.id from (select max(id) as id from facefeat)a)"
                            dBase.execute(sql, matrix_dimension)
                            QMessageBox.information(self, "信息录入", "信息录入成功")
                        except:
                            QMessageBox.information(self, "信息录入", "信息录入失败")
                    else:
                        QMessageBox.information(self, "信息录入", "请录入个人照片")
                else:
                    QMessageBox.information(self, "信息录入", "请录入个人照片")

    # 录入照片
    def capFace(self):
        name = self.nameEdit.toPlainText()  # 获取普通文本
        num = self.numEdit.toPlainText()
        if not os.path.exists(image_path):
            os.mkdir(image_path)  # 如果没有存储相片的目录，则进行创建
        flag = True
        if name != '' and num != '':
            dBase = dataBase()
            sql = 'SELECT * FROM employees'
            result = dBase.fetchall(sql)
            for i in range(len(result)):
                if result[i][1] == num:
                    flag = False
                    QMessageBox.information(self, "信息录入", "编号重复了！")
            if flag:
                if not os.path.exists(image_path + num):
                    os.mkdir(image_path + num)  # 如果没有员工照片个人目录，则创建
                capture_face(num)
        else:
            QMessageBox.information(self, "信息录入", "请完善个人信息")  # 必须拥有两个参数

    # 从本地添加员工照片
    def addPhoto(self):
        name = self.nameEdit.toPlainText()  # 获取普通文本
        num = self.numEdit.toPlainText()
        if not os.path.exists(image_path):
            os.mkdir(image_path)  # 如果没有存储相片的目录，则进行创建
        flag = True
        if name != '' and num != '':
            dBase = dataBase()
            sql = 'SELECT * FROM employees'
            result = dBase.fetchall(sql)
            for i in range(len(result)):
                if result[i][1] == num:
                    flag = False
                    QMessageBox.information(self, "信息录入", "编号重复了！")
            if flag:
                f_name = QFileDialog.getOpenFileName(self, 'open file', '/', '*.jpg *.png')
                if f_name[0]:
                    try:
                        if not os.path.exists(image_path + num):
                            os.mkdir(image_path + num)  # 如果没有员工照片个人目录，则创建
                        image_name = open(f_name[0], 'r')
                        image = image_name.name  # 获取image路径
                        print('image', image)
                        dirs = image_path + num
                        print('dirs', dirs)
                        if image_face(image, dirs):
                            QMessageBox.information(self, "添加照片", "添加成功")
                        else:
                            QMessageBox.information(self, "检测不出人脸", "请重新换张照片")
                    except:
                        QMessageBox.information(self, "本地录入照片", "可能文件类型错误！")
        else:
            QMessageBox.information(self, "信息录入", "请完善个人信息")  # 必须拥有两个参数


class AdminWin(QDialog, admin.Ui_AdminWin):
    def __init__(self):
        super(AdminWin, self).__init__()
        self.setupUi(self)
        self.tableWidget.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
        self.tableWidget.customContextMenuRequested[QPoint].connect

    def showAddinfor(self):
        add_inf = AddWin()
        add_inf.show()
        add_inf.exec_()

    def showStatis(self):
        dBase = dataBase()
        sql = "select r.staffNum, e.name, dates, recordTime from record as r, employees as e \
               where r.staffNum = e.staffNum order by (r.staffNum) desc"
        result = dBase.fetchall(sql)
        row_num = 0

        _translate = QtCore.QCoreApplication.translate
        item = self.tableWidget.horizontalHeaderItem(3)
        item.setText(_translate("AdminWin", "识别次数"))
        self.tableWidget.clearContents()

        staff_num = []
        record_date = []

        for i in range(len(result)):
            staff_num.append(result[i][0])  # 获取员工编号
            record_date.append(datetime.strftime(result[i][3], '%Y-%m'))  # 获取识别日期，年月

        lens = len(set(staff_num))  # 员工识别人数为表格行数
        self.tableWidget.setRowCount(lens)
        staff_num = []

        for dat in set(record_date):  # 获取某一月份的员工识别情况
            cont = '%' + dat + '%'  # "%" 可用于定义通配符（模式中缺少的字母）
            sql = "select r.staffNum, e.name, dates, recordTime from record as r, employees as e \
                                     where r.staffNum = e.staffNum and r.dates LIKE '%s' order by (r.staffNum) desc" % (cont)
            results = dBase.fetchall(sql)

            for i in range(len(results)):
                staff_num.append((results[i][0], results[i][1]))  # 获取该名员工的编号及姓名

            for item in set(staff_num):
                col_num = 0  # 列数
                content = (item[0], item[1], dat, str(staff_num.count(item)))  # 每一行的内容
                for staff_item in content:
                    new_item = QTableWidgetItem(staff_item)
                    self.tableWidget.setItem(row_num, col_num, new_item)
                    col_num += 1
                row_num += 1
            staff_num = []

    def showRecord(self):
        dBase = dataBase()
        sql = "select r.staffNum, e.name, dates, recordTime from record as r, employees as e \
        where r.staffNum = e.staffNum order by (r.staffNum) desc"
        result = dBase.fetchall(sql)
        lens = dBase.fetchall(sql).__len__()
        self.tableWidget.setRowCount(lens)
        row_num = 0
        _translate = QtCore.QCoreApplication.translate
        item = self.tableWidget.horizontalHeaderItem(3)
        item.setText(_translate("AdminWin", "识别具体时间"))
        for i in range(len(result)):
            col_num = 0  # 列
            for j in result[i]:
                if isinstance(j, datetime):  # 判断是否为datetime.datetime类型
                    j = datetime.strftime(j, '%Y-%m-%d %H:%M:%S')
                new_item = QTableWidgetItem(j)
                self.tableWidget.setItem(row_num, col_num, new_item)
                col_num += 1
            row_num += 1

    def searchRecord(self):
        dBase = dataBase()
        sql = ""
        _translate = QtCore.QCoreApplication.translate
        item = self.tableWidget.horizontalHeaderItem(3)
        item.setText(_translate("AdminWin", "识别具体时间"))
        if (self.searchEdit.text() != ""):
            content = self.searchEdit.text()
            cont = '%' + content + '%'  # "%" 可用于定义通配符（模式中缺少的字母）
            choice = self.comboBox.currentText()
            if (choice == '按编号查询'):
                sql = "select r.staffNum, e.name, dates, recordTime from record as r, employees as e \
                      where r.staffNum = e.staffNum and r.staffNum LIKE '%s' order by (r.staffNum) desc" % (cont)

            elif(choice == "按名字查询"):
                sql = "select r.staffNum, e.name, dates, recordTime from record as r, employees as e \
                      where r.staffNum = e.staffNum and e.name LIKE '%s' order by (r.staffNum) desc" % (cont)

            elif (choice == "按日期查询"):
                sql = "select r.staffNum, e.name, dates, recordTime from record as r, employees as e \
                      where r.staffNum = e.staffNum and r.dates LIKE '%s' order by (r.staffNum) desc" %(cont)

            self.tableWidget.clearContents()  # 清空表格内容
            result = dBase.fetchall(sql)
            lens = dBase.fetchall(sql).__len__()   # 输出匹配的行数
            self.tableWidget.setRowCount(lens)
            row_num = 0
            for i in range(lens):
                col_num = 0
                for j in result[i]:
                    if isinstance(j, datetime):  # 判断是否为datetime.datetime类型
                        j = datetime.strftime(j, '%Y-%m-%d %H:%M:%S')
                    new_item = QTableWidgetItem(j)
                    self.tableWidget.setItem(row_num, col_num, new_item)
                    col_num += 1
                row_num += 1

    def inf_show(self):
        mouse_right = QtWidgets.QMenu(self.tableWidget)
        remove_inf = QtWidgets.QAction(u"删除", self, triggered=self.deleteInfo)
        mouse_right.addAction(remove_inf)
        mouse_right.exec_(QtGui.QCursor.pos())

    def deleteInfo(self):
        dBase = dataBase()
        row = self.tableWidget.currentRow()
        staff_num = self.tableWidget.item(row, 0).text()
        record_date = self.tableWidget.item(row, 2).text()
        warn = QMessageBox.question(self, '提示', '确定删除数据吗？', QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if warn == QMessageBox.Yes:
            sql = "delete from record where staffNum='%s' and dates='%s'" % (staff_num, record_date)
            dBase.execute(sql)

            self.tableWidget.removeRow(row)


class faceWin(QMainWindow, win.Ui_MainWindow):
    def __init__(self):
        super(faceWin, self).__init__()
        self.setupUi(self)
        self.videostatus = 0
        self.timer_camera = QTimer(self)
        self.begin = time.time()
        self.fps = 0
        self.timer_camera.timeout.connect(self.face_rec)

    # 员工识别
    def showCamera(self):
        # if self.punchButton.clicked:
        #     face_rec()
        if self.videostatus == 0:
            self.capture = cv2.VideoCapture(0)
            self.timer_camera.start(1)
            self.videostatus = 1
        else:
            self.capture = self.capture.release()
            self.videostatus = 0
            self.timer_camera.stop()
            self.label.clear()
            self.showResult.setText('')


    def face_rec(self):
        dBase = dataBase()
        sql = 'SELECT * FROM employees'
        result = dBase.fetchall(sql)  # result 是一个元组
        sql = 'SELECT * FROM facefeat where id=(select max(id) from facefeat)'
        res = dBase.fetchall(sql)[0]  # dBase.fetchall(sql2)返回的形式类((b'[[[-5.77707522e+03]]]','(390,21,20)'),)
        feature = res[1]  # 获取特征
        feature = np.frombuffer(feature)  # 还原成一维数组
        # print('feature.shape', feature.shape)
        dimension = res[2]
        dim = pickle.loads(dimension)  # 还原成数组
        # print('dim', dim)
        feat = feature.reshape(dim)  # 将数组还原成多为数组
        # print('feat.shape', feat.shape)
        label = []
        for i in range(len(result)):
            label.append(result[i][1])
        ret, frame = self.capture.read()
        height, width, bytesPerComponent = frame.shape   # 图片水平width，垂直height的彩色图
        bytesPerLine = 3 * width
        frame, staff_num = recg(frame, feat)

        self.fps += 1
        sfps = self.fps / (time.time() - self.begin)
        cv2.putText(frame, 'FPS: ' + str(int(sfps)), (30, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)

        for i in range(len(label)):
            if label[i] == staff_num:
                flag = addRecord(staff_num)
                if flag:
                    # cv2.putText(frame, 'Success', (50, 80), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2,cv2.LINE_AA, )
                    self.showResult.setText(staff_num + ' record success')
        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        QImag = QImage(frame.data, width, height, bytesPerLine, QImage.Format_RGB888)
        img = QPixmap.fromImage(QImag)
        if width / height > self.label.width() / self.label.height():
            img = img.scaled(self.label.height() * width / height, self.label.height())
        else:
            img = img.scaled(self.label.width(), self.label.width() * height / width)
        self.label.setPixmap(img)

    # 当管理员要录入信息时需要先登录
    def showLogin(self):
        if self.adminButton.clicked:
            login = LoginWin()
            login.show()
            login.exec_()

    


# 人脸识别
def face_rec():
    dBase = dataBase()
    sql = 'SELECT * FROM employees'
    result = dBase.fetchall(sql)  # result 是一个元组
    sql = 'SELECT * FROM facefeat where id=(select max(id) from facefeat)'
    res = dBase.fetchall(sql)[0]  # dBase.fetchall(sql2)返回的形式类((b'[[[-5.77707522e+03]]]','(390,21,20)'),)
    feature = res[1]  # 获取特征
    feature = np.frombuffer(feature)  # 还原成一维数组
    print('feature.shape', feature.shape)
    dimension = res[2]
    dim = pickle.loads(dimension)  # 还原成数组
    print('dim', dim)
    feat = feature.reshape(dim)  # 将数组还原成多为数组
    print('feat.shape', feat.shape)
    label = []
    for i in range(len(result)):
        label.append(result[i][1])
    capture = cv2.VideoCapture(0)
    # capture.set(3, 400)
    # capture.set(3, 300)
    while(capture.isOpened()):
        ret, frame = capture.read()
        frame, staff_num = recg(frame, feat)
        for i in range(len(label)):
            if label[i] == staff_num:
                flag = addRecord(staff_num)
                if flag:
                    cv2.putText(frame, 'Success', (50, 80), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2, cv2.LINE_AA, )
        cv2.imshow('camera', frame)
        if cv2.waitKey(1) & 0xFF == 27:
            break

    capture.release()
    cv2.destroyAllWindows()


# 识别记录
def addRecord(staffnum):   # 识别记录
    dt = datetime.now().strftime("%Y-%m-%d")  # 获取当前时间
    dBase = dataBase()
    sql = "select * from record"
    result = dBase.fetchall(sql)
    if result:
        sql = "select id ,dates from record where staffNum='%s' order by id desc limit 1" %staffnum
        result = dBase.fetchall(sql)
        if result:
            resu = result[0]
            record_time = resu[1]
            if dt != record_time:
                sql = "insert into record (staffNum) values(%s)"
                dBase.execute(sql, staffnum)
                sql = "update record set dates=%s where id in (select a.id from (select max(id) as id from record)a)"
                flag = dBase.execute(sql, dt)
                print('识别成功！')
                return flag
        else:
            sql = "insert into record (staffNum) values(%s)"
            dBase.execute(sql, staffnum)
            sql = "update record set dates=%s where id in (select a.id from (select max(id) as id from record)a)"
            flag = dBase.execute(sql, dt)
            print('识别成功！')
            return flag
    else:
        sql = "insert into record (staffNum) values(%s)"
        dBase.execute(sql, staffnum)
        sql = "update record set dates=%s where id in (select a.id from (select max(id) as id from record)a)"
        flag = dBase.execute(sql, dt)
        print('识别成功！')
        return flag





if __name__ == '__main__':
    app = QApplication(sys.argv)
    MainWin = faceWin()
    MainWin.show()
    sys.exit(app.exec_())



