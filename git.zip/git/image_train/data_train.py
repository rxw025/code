import tensorflow as tf
import numpy as np
import cv2, os
from face_recog import facenet
from image_train.dataset import DataSet

dir_model = './model'
dir_image_train = './image_train'

image_size = 200


def train():
    # 建立facenet embedding模型
    model_dir = dir_model + '/facenet_model/facenet_model.pb'
    tf.Graph().as_default()
    sess = tf.Session()
    facenet.load_model(model_dir)
    images_placeholder = tf.get_default_graph().get_tensor_by_name("input:0")
    embeddings = tf.get_default_graph().get_tensor_by_name("embeddings:0")
    phase_train_placeholder = tf.get_default_graph().get_tensor_by_name("phase_train:0")
    embedding_size = embeddings.get_shape()[1]

    datas = DataSet()
    train_path = datas.image_train
    target_name = datas.target_name
    every_staff_image_num = datas.every_staff_image
    emb_array1 = np.zeros((len(train_path), embedding_size))
    emb_array2 = np.zeros((len(target_name), embedding_size))
    scaled_reshape = []

    k = 0
    j = 0
    sum = every_staff_image_num[0]
    for i in range(len(train_path)):
        image_name = train_path[i]
        image = cv2.imread(image_name)
        image = cv2.resize(image, (image_size, image_size), interpolation=cv2.INTER_CUBIC)
        image = facenet.prewhiten(image)
        scaled_reshape.append(image.reshape(-1, image_size, image_size, 3))
        emb_array1[i, :] = sess.run(embeddings, feed_dict={images_placeholder: scaled_reshape[i], phase_train_placeholder: False })[0]
        if (i + 1) % sum == 0:
            emb_array2[k, :] = np.mean(emb_array1[j:sum], 0)   # 对每个员工的照片特征列向取余
            k += 1
            j = i+1
            if len(every_staff_image_num) - 1 >= k:
                sum += every_staff_image_num[k]
    print('emb_array2.shape', emb_array2.shape)
    return emb_array2, emb_array2.shape

# train()


