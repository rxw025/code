import os
import numpy as np


dir = './image_train'


class DataSet:
    def __init__(self):
        self.path = './image'
        self.image_train = []  # 存储被训练的每张图片的具体路径
        self.target_name = []
        self.every_staff_image = []  # 存储每个员工的照片数量
        self.num = 0

        path = [os.path.join(self.path, pth) for pth in os.listdir(self.path)]
        for dir_path in path:
            self.target_name += [os.path.split(dir_path)[-1]]  # 获取每张图片所属的label
            if os.path.isdir(dir_path):
                for image_name in os.listdir(dir_path):
                    image_path = os.path.join(dir_path, image_name)  # 获得每张image的具体路径，如.\images\ORL\p1\10.jpg
                    self.image_train += [image_path]
                    self.num += 1
                self.every_staff_image.append(self.num)
            self.num = 0
        print('self.every_staff_image', self.every_staff_image)
        np.save(dir + '\\' + 'target_name', self.target_name)
        print('SAVE')
