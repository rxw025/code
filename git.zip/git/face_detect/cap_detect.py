import os
import numpy as np
import cv2
import time
from face_detect.face_detector import FaceDetector
os.environ['CUDA_VISIBLE_DEVICES'] = '0,1'#指定显存为0号和1号

dir_model = './model'
dir_image = './image/'
MODEL_PATH = dir_model + '/faceboxes_model/model.pb'#模型的路径
face_detector = FaceDetector(MODEL_PATH, gpu_memory_fraction=0.25, visible_device_list='0')


#  Note that box coordinates are in the order: ymin, xmin, ymax, xmax!

def capture_face(num):
    count = 0
    capture = cv2.VideoCapture(0)
    capture.set(3, 680)
    capture.set(4, 480)

    begin = time.time()
    fps = 0

    while (capture.isOpened()):
        ret, frame = capture.read()
        img = np.copy(frame)
        waitkey = cv2.waitKey(1)

        # begin = time.time()

        boxes, scores = face_detector(frame, score_threshold=0.6)

        max_dis = []  # 存储最大boxes的对角线距离
        for i in range(boxes.shape[0]):
            bbox = boxes[i, :4]
            if int(bbox[0]) > 0 and int(bbox[1]) > 0 and int(bbox[2]) > 0 and int(bbox[3]) > 0:
                x = np.array([int(bbox[1]), int(bbox[0])])  # 左上角坐标
                y = np.array([int(bbox[3] - bbox[1]), int(bbox[2] - bbox[0])])  # 右下角坐标
                dis = np.sqrt(np.sum(np.square(x - y)))  # 两点间欧氏距离
                max_dis.append(dis)  # 如果有多个人脸框，获取最大的那个
                cv2.rectangle(frame, (int(bbox[1]), int(bbox[0])), (int(bbox[3]), int(bbox[2])), (0, 255, 0))
        if len(max_dis) > 0:
            index = max_dis.index(max(max_dis))
            bbox = boxes[index, :4]
            image = img[int(bbox[0]):int(bbox[2]), int(bbox[1]):int(bbox[3])]
            if waitkey & 0xFF == 32:  # 按空格键进行拍照
                # image = cv2.resize(image, (92, 112))
                cv2.imwrite(dir_image + num + '\\' + str(count) + '.jpg', image)  # 存储相片
                count += 1
                print('success')  # 用于测验成功存储相片

        # end = time.time() - begin
        # cv2.putText(frame, str(int(1 / end)) + " fps", (30, 30), 0, 1, [0, 0, 255], thickness=3, lineType=cv2.LINE_AA)
        fps += 1
        sfps = fps / (time.time() - begin)
        cv2.putText(frame, str(int(sfps)) + " fps", (30, 30), 0, 1, [0, 0, 255], thickness=3, lineType=cv2.LINE_AA)
        cv2.imshow('Camera', frame)  # 展示视频画面

        if waitkey & 0xFF == 27:  # 按Esc键退出摄像头拍照
            break

    capture.release()
    cv2.destroyAllWindows()


# capture_face('6')