import tensorflow as tf
import numpy as np


class FaceDetector:
    def __init__(self, model_path, gpu_memory_fraction=0.25, visible_device_list='0'):
        #模型路径，分配给gpu的显存比例，进程可见的GPU设备默认第0块
        """
        Arguments:
            model_path: a string, path to a pb file.
            gpu_memory_fraction: a float number.
            visible_device_list: a string.
        """
        #with类似于异常处理
        with tf.gfile.GFile(model_path, 'rb') as f:#将模型调入graph
            graph_def = tf.GraphDef()
            graph_def.ParseFromString(f.read())

        graph = tf.Graph()#生成默认图类似空壳
        with graph.as_default():#将导入的模块作为默认图并命名import
            tf.import_graph_def(graph_def, name='import')

        self.input_image = graph.get_tensor_by_name('import/image_tensor:0')#整理张量
        self.output_ops = [
            graph.get_tensor_by_name('import/boxes:0'),
            graph.get_tensor_by_name('import/scores:0'),
            graph.get_tensor_by_name('import/num_boxes:0'),
        ]

        gpu_options = tf.GPUOptions(
            per_process_gpu_memory_fraction=gpu_memory_fraction,
            visible_device_list=visible_device_list
        )
        config_proto = tf.ConfigProto(gpu_options=gpu_options, log_device_placement=False)#限制GPU使用 False
        self.sess = tf.Session(graph=graph, config=config_proto)#开启会话

    def __call__(self, image, score_threshold=0.5):#对象变成一个可调用的对象，score_threshold表示可信度
        """Detect faces.

        Arguments:
            image: a numpy uint8 array with shape [height, width, 3],
                that represents a RGB image.
            score_threshold: a float number.
        Returns:
            boxes: a float numpy array of shape [num_faces, 4].
            scores: a float numpy array of shape [num_faces].

        Note that box coordinates are in the order: ymin, xmin, ymax, xmax!
        """
        h, w, _ = image.shape
        image = np.expand_dims(image, 0)#在0号位置增加一个维度[高度，宽度，通道]->[1，高度，宽度，通道]单一形状变成图像
        boxes, scores, num_boxes = self.sess.run(
            self.output_ops, feed_dict={self.input_image: image}#张量整理成字典
        )
        num_boxes = num_boxes[0]
        boxes = boxes[0][:num_boxes]
        scores = scores[0][:num_boxes]

        to_keep = scores > score_threshold
        boxes = boxes[to_keep]
        scores = scores[to_keep]

        scaler = np.array([0.9*h, 0.92*w, 1.06*h, 1.05*w], dtype='float32')
        boxes = boxes * scaler

        return boxes, scores
