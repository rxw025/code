import os
import numpy as np
import cv2
import time
from face_detect.face_detector import FaceDetector
os.environ['CUDA_VISIBLE_DEVICES'] = '0,1'

dir_model = './model/'
dir_image = './image/'

MODEL_PATH = dir_model + 'faceboxes_model/model.pb'
face_detector = FaceDetector(MODEL_PATH, gpu_memory_fraction=0.25, visible_device_list='0')


def image_face(img, dirs):
    count = 0
    num_list = []
    if os.listdir(dirs):
        print(dirs)
        for image_name in os.listdir(dirs):
            num_list.append(os.path.split(image_name)[-1].split('.')[0])
        count = int(max(num_list)) + 1

    image = cv2.imread(img)
    print(image)
    imgs = np.copy(image)
    boxes, scores = face_detector(imgs, score_threshold=0.6)
    for i in range(boxes.shape[0]):
        print(boxes)
        bbox = boxes[i, :4]
        if int(bbox[0]) > 0 and int(bbox[1]) > 0 and int(bbox[2]) > 0 and int(bbox[3]) > 0:
            image = imgs[int(bbox[0]):int(bbox[2]), int(bbox[1]):int(bbox[3])]
            cv2.imwrite(dirs + '\\' + str(count) + '.jpg', image)  # 存储相片
            return True

